<footer>

    <p>&copy;<?php echo date("y");?> PHP WEBSITE BY Sahil Malik. ALL RIGHT RESERVED</P>

</footer>