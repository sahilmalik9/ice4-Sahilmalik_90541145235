<?php include 'header.php'; ?>

<main>
   <h1>About us</h1>
    <p>this is about my page</p>
    <img src="images/photo.jpg"  height="500" width="500" alt="Sahil Malik">
    <div
     class="about-photo">
</div>
    <?php
     $team=["Sahil Malik - developer"];
     ?>

     <ul>
        <?php foreach($team as $member) : ?>
            <li><?php echo $member ;?></li>
            <?php endforeach;?>
        </ul>
        </main>
        <?php include 'footer.php';?>