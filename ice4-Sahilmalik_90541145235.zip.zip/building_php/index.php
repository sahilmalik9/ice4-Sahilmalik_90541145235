<?PHP include 'header.php';?>
<main>
    <h1>WELCOME TO MY FIRST PHP WEBSITE</h1>
    <p>THIS IS MY HOME PAGE</P>
</main>
<?php include 'footer.php';?>

